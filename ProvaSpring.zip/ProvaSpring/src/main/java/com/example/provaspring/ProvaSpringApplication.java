package com.example.provaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProvaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvaSpringApplication.class, args);
	}

}
