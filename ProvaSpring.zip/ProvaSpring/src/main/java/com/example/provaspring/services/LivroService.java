package com.example.provaspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.provaspring.entities.Livro;
import com.example.provaspring.repository.LivroRepository;

@Service
	@Transactional
	public class LivroService {

		@Autowired
		private LivroRepository livroRepository;
		
		public List<Livro> getAllLivros() {
			return livroRepository.findAll();
		}
		
		public void saveLivro(Livro livro) {
			livroRepository.save(livro);
		}
}
