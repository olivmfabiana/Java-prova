package com.example.provaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
